# Homework 3
**Thomas Kaunzinger**
*CS4610*

## YouTube Video
`https://youtu.be/9sGtCTw_ksU`

## Comments
This was finneky as hell to not crash and die, but I'm glad I got it in the end.
