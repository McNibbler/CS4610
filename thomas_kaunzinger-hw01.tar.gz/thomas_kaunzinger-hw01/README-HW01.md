# Homework 1
**Thomas Kaunzinger**
*CS4610*

## YouTube Video
https://youtu.be/QiKJdPxxkPI
*Note: I noticed in my recording that I didn't say my name at first, so I say it at the end of the video*

## GitHub Link
https://github.com/McNibbler/CS4610

## Additional Comments
After figuring out the setup, this assignment wasn't particularly hard, although my solution is far from optimal.

My configuration is as follows:

- Asus Zenbook Pro ux580
- kubuntu 20.04
- Gazebo 11
