# Homework 8
**Thomas Kaunzinger**
*CS4610*

## YouTube Video
`https://youtu.be/kerpGcpH_i0`

## Comments
As I mentioned in the video, this has been another challenging experience. I think my reasoning
behind the camera mapping is mostly correct, but the unreliable nature of the camera has greatly
hindered me when trying to make any substantial progress. I hope you will at least appreciate
my feeble attempt :(

## Pull Request
`https://github.com/NatTuck/cs5335hw-gazebo/pull/16`

I had noticed that the pathfinding was directing the robot to the incorrect goal location in the
example solution for Homework 7, so I had adjusted the solution to actually go towards the correct
goal.

