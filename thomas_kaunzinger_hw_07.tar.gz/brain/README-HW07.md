# Homework 7
**Thomas Kaunzinger**
*CS4610*

## YouTube Video
`https://youtu.be/pubg-75CyU8 `

## GitHub Repo
`https://github.com/McNibbler/CS4610`

## Extra Credit
`https://github.com/McNibbler/gazebo_bubble_mazegen`

## Comments
This went really badly...

Please let me know if you can figure out why my Astar appears to be
searching for anything *but* the direction of the goal. Regardless,
I've been spending all week trying to figure it out and I haven't
slept in days, so I'm just gonna settle with what I have. If I end
up getting a better solution tonight, I will update the submission.
