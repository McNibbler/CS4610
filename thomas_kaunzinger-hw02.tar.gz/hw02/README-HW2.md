# Homework 2
**Thomas Kaunzinger**
*CS4610*

## Youtube Video
> Note: I accidentally used 2 audio sources to record this, so there is some massive echo.
https://youtu.be/VQtYhTy-QpE

## Delta-V
I only finished with 258m/s Delta-V at the end of this launch.
A more efficient algorithm is very likely possible, but I am brand new to KSP, so I was happy with this.

## Comments
I know you said the hard part of this assignment was supposed to be to get KSP + kOS up and running,
but frankly I really suck at this game, and it took me seemingly ages before I could figure out how
to circularize this orbit. Regardless, I finally did it, so all is good in the hood.

